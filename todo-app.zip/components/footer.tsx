import { Instagram, Mail, Phone, PhoneIcon as WhatsappIcon } from "lucide-react"
import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t py-6 md:py-0 bg-blue-50">
      <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Бекжан Пирмаханов. Все права защищены.
        </p>
        <div className="flex items-center gap-4">
          <Link href="mailto:pirmakhanov.b@gmail.com" className="text-sm text-muted-foreground hover:text-blue-700">
            <span className="flex items-center gap-1">
              <Mail className="h-4 w-4" />
              pirmakhanov.b@gmail.com
            </span>
          </Link>
          <Link href="tel:+77082382618" className="text-sm text-muted-foreground hover:text-blue-700">
            <span className="flex items-center gap-1">
              <Phone className="h-4 w-4" />
              +7 (708) 238 26 18
            </span>
          </Link>
          <a
            href="https://wa.me/77082382618?text=Сәлеметсіз%20бе!%20Мен%20консультацияға%20жазылғым%20келеді.%20Здравствуйте!%20Хочу%20записаться%20на%20консультацию"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-muted-foreground hover:text-blue-700"
          >
            <span className="flex items-center gap-1">
              <WhatsappIcon className="h-4 w-4" />
              WhatsApp
            </span>
          </a>
          <a
            href="https://www.instagram.com/bekzhan.rehab.doc?igsh=MXdyYjZlOWU2NGhwaA=="
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-muted-foreground hover:text-blue-700"
          >
            <span className="flex items-center gap-1">
              <Instagram className="h-4 w-4" />
              Instagram
            </span>
          </a>
        </div>
      </div>
    </footer>
  )
}
