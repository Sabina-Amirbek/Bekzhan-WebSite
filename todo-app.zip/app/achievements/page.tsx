import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Award, Medal, Mountain, Video, Briefcase } from "lucide-react"
import Image from "next/image"

export default function AchievementsPage() {
  return (
    <div className="container px-4 py-12">
      <div className="space-y-2 text-center mb-8">
        <h1 className="text-3xl font-bold">Достижения</h1>
        <p className="text-muted-foreground">Профессиональные и личные достижения</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-5xl mx-auto">
        <Card className="overflow-hidden">
          <div className="bg-primary h-1.5"></div>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Профессиональные достижения
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="space-y-1">
                <h3 className="font-medium">Чемпион Казахстанской Футбольной Лиги</h3>
                <p className="text-sm text-muted-foreground">2024</p>
              </li>
              <li className="space-y-1">
                <h3 className="font-medium">Обладатель Суперкубка Казахстана</h3>
                <p className="text-sm text-muted-foreground">2025</p>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="bg-primary h-1.5"></div>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Medal className="h-5 w-5" />
              Научные достижения
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="space-y-1">
                <h3 className="font-medium">9 научных публикаций</h3>
                <p className="text-sm text-muted-foreground">В международных рецензируемых журналах</p>
              </li>
              <li className="space-y-1">
                <h3 className="font-medium">PhD кандидат</h3>
                <p className="text-sm text-muted-foreground">Общественное здравоохранение</p>
              </li>
              <li className="space-y-1">
                <h3 className="font-medium">Case Presenter</h3>
                <p className="text-sm text-muted-foreground">
                  Salzburg Weill Cornell Seminar in Rehabilitation Medicine, 2024
                </p>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <div className="bg-primary h-1.5"></div>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Mountain className="h-5 w-5" />
              Личные достижения
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="space-y-1">
                <h3 className="font-medium">Восхождение на базовый лагерь Эвереста</h3>
                <p className="text-sm text-muted-foreground">5364 м над уровнем моря</p>
              </li>
              <li className="space-y-1">
                <h3 className="font-medium">Владение 5 языками</h3>
                <p className="text-sm text-muted-foreground">Казахский, русский, английский, французский, украинский</p>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 max-w-5xl mx-auto">
        <Card className="border-blue-100 shadow-sm overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Video className="h-5 w-5" />
              Выступления и презентации
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">XIII Международный симпозиум по спортивной медицине и реабилитологии</h3>
              <div className="aspect-video w-full rounded-md overflow-hidden">
                <iframe
                  width="100%"
                  height="100%"
                  src="https://www.youtube.com/embed/u3Ln9WMX7QI"
                  title="XIII Международный симпозиум по спортивной медицине и реабилитологии"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Выступление в качестве спикера на XIII Международном симпозиуме по спортивной медицине и реабилитологии
              </p>
            </div>

            <div>
              <h3 className="font-medium mb-2">Salzburg Weill Cornell Seminar in Rehabilitation Medicine</h3>
              <div className="relative aspect-video w-full rounded-md overflow-hidden">
                <Image
                  src="/images/presentation-photo.png"
                  alt="Выступление на Salzburg Weill Cornell Seminar"
                  fill
                  className="object-cover"
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Выступление в качестве case presenter на семинаре Salzburg Weill Cornell Seminar in Rehabilitation
                Medicine, 2024
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-100 shadow-sm mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Мастер-классы и повышение квалификации
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              <li className="space-y-1">
                <h3 className="font-medium">MULLIGAN. Manual Therapy Concept</h3>
                <p className="text-sm text-muted-foreground">Астана, 2024</p>
              </li>
                            <li className="space-y-1">
                <h3 className="font-medium">Open Medical Institute (OMI).Physical Medicine and Rehabilitation Seminar</h3>
                <p className="text-sm text-muted-foreground">Австрия, 2024</p>
              </li>
                            <li className="space-y-1">
                <h3 className="font-medium">FC Red Bull Salzburg</h3>
                <p className="text-sm text-muted-foreground">Австрия, 2024</p>
              </li>
                            <li className="space-y-1">
                <h3 className="font-medium">FC CSKA Moscow</h3>
                <p className="text-sm text-muted-foreground">Российская Федерация, 2022</p>
              </li>
                            <li className="space-y-1">
                <h3 className="font-medium">World anti-doping agency (WADA).ADel Sport Physician's Tool Kit Certificate </h3>
                <p className="text-sm text-muted-foreground">2019</p>
              </li>
              <li className="space-y-1">
                <h3 className="font-medium">The Federation Internationale de Football Association (FIFA). FIFA Diploma in Football Medicine</h3>
                <p className="text-sm text-muted-foreground">2019</p>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="mt-8 max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle>Профессиональные навыки</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <h3 className="font-medium mb-2">Медицинские навыки</h3>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li>Спортивная реабилитация</li>
                  <li>Мануальная терапия</li>
                  <li>Диагностика спортивных травм</li>
                  <li>Разработка программ восстановления</li>
                  <li>Профилактика травматизма</li>
                </ul>
              </div>
              <div>
                <h3 className="font-medium mb-2">Исследовательские навыки</h3>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li>Планирование исследований</li>
                  <li>Статистический анализ</li>
                  <li>Научные публикации</li>
                  <li>Презентация результатов</li>
                  <li>Работа с научной литературой</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
