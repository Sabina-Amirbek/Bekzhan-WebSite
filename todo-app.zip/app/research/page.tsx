import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ExternalLink } from "lucide-react"
import Link from "next/link"

export default function ResearchPage() {
  const publications = [
    {
      id: 1,
      title:
        "Среднесрочное влияние болезни Осгуда-Шлаттера на функцию коленного сустава у молодых игроков из элитных футбольных академий",
      journal: "The Physician and Sportsmedicine",
      year: "2022",
      url: "https://doi.org/10.1080/00913847.2022.2148492",
    },
    {
      id: 2,
      title:
        "Влияние однократной дозы цитруллина на физическую работоспособность при выполнении специфических для футбола упражнений у взрослых элитных футболистов (Пилотное рандомизированное двойное слепое исследование)",
      journal: "Nutrients",
      year: "2022",
      url: "https://doi.org/10.3390/nu14235036",
    },
    {
      id: 3,
      title:
        "Спортивная реабилитация, но не инъекции PRP, могут снизить частоту повторных травм мышц у профессиональных футболистов: ретроспективное когортное исследование",
      journal: "Journal of Functional Morphology and Kinesiology",
      year: "2022",
      url: "https://doi.org/10.3390/jfmk7040072",
    },
    {
      id: 4,
      title: "Относительный возрастной эффект у лучших легкоатлетов в возрасте от 10 до 15 лет",
      journal: "Sports",
      year: "2022",
      url: "https://doi.org/10.3390/sports10070101",
    },
    {
      id: 5,
      title:
        "Показатели бега во время священного месяца Рамадан у элитных профессиональных взрослых футболистов в России",
      journal: "Int. J. Environ. Res. Public Health",
      year: "2021",
      url: "https://doi.org/10.3390/ijerph182111731",
    },
    {
      id: 6,
      title: "Цитруллин в спорте высших достижений: есть ли в этом смысл?",
      journal: "Science and sport: current trends",
      year: "2022",
      url: "https://doi.org/10.36028/2308-8826-2022-10-4-25-35",
    },
    {
      id: 7,
      title:
        "Рост, вес, сила и скорость в большей степени зависят от состояния биологического созревания, чем от хронологического возраста",
      journal: "Clinical Journal of Sport Medicine",
      year: "2023",
      url: "https://doi.org/10.1097/JSM.0000000000001124",
      type: "тезис",
    },
    {
      id: 8,
      title:
        "В элитной легкой атлетике старшего возраста наблюдается обратный эффект относительного возраста: успешные молодые люди являются «спортсменами раннего рождения», в то время как среди взрослых больше спортсменов «Позднего рождения»",
      journal: "Clinical Journal of Sport Medicine",
      year: "2023",
      url: "https://doi.org/10.1097/JSM.0000000000001124",
      type: "тезис",
    },
    {
      id: 9,
      title:
        "Эффект относительного возраста широко распространен среди взрослых профессиональных футболистов Европы, но не влияет на их рыночную стоимость",
      journal: "Plos One",
      year: "2023",
      url: "https://doi.org/10.1371/journal.pone.0283390",
    },
  ]

  return (
    <div className="container px-4 py-12">
      <div className="space-y-2 text-center mb-8">
        <h1 className="text-3xl font-bold">Исследования</h1>
        <p className="text-muted-foreground">Научные публикации и исследовательская деятельность</p>
        <div className="flex justify-center mt-4">
          <Link
            href="https://orcid.org/0000-0002-1512-8141"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm flex items-center gap-1 text-muted-foreground hover:text-foreground"
          >
            ORCID: 0000-0002-1512-8141
            <ExternalLink className="h-3 w-3" />
          </Link>
        </div>
      </div>

      <div className="space-y-6 max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle>Научные публикации</CardTitle>
            <CardDescription>Статьи в рецензируемых научных журналах</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {publications.map((pub) => (
                <div key={pub.id} className="border-b pb-4 last:border-0 last:pb-0">
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h3 className="font-medium">
                        {pub.id}. {pub.title} {pub.type && <span className="text-sm">({pub.type})</span>}
                      </h3>
                      <div className="text-sm text-muted-foreground mt-1">
                        <span>
                          {pub.journal}, {pub.year}
                        </span>
                      </div>
                    </div>
                    <Link
                      href={pub.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm shrink-0 flex items-center gap-1 text-muted-foreground hover:text-foreground"
                    >
                      DOI
                      <ExternalLink className="h-3 w-3" />
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Области исследований</CardTitle>
            <CardDescription>Основные направления научной деятельности</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="list-disc pl-5 space-y-2">
              <li>Спортивная медицина и реабилитация в футболе</li>
              <li>Эффект относительного возраста у спортсменов</li>
              <li>Влияние пищевых добавок на физическую работоспособность</li>
              <li>Травмы и реабилитация у молодых спортсменов</li>
              <li>Профилактика повторных травм у профессиональных спортсменов</li>
              <li>Влияние религиозных практик на спортивные показатели</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
