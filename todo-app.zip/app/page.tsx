import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Instagram, Mail, Phone, PhoneIcon as WhatsappIcon } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container px-4 py-12 md:py-24">
      <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
        <div className="flex flex-col justify-center space-y-4">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl text-blue-700">Бекжан Пирмаханов</h1>
            <p className="text-xl text-muted-foreground">Доктор спортивной медицины и медицинской реабилитологии</p>
          </div>
          <div className="space-y-4 text-muted-foreground">
            <p>
              PhD кандидат в области общественного здравоохранения с обширным опытом в спортивной медицине и
              реабилитации. В настоящее время работаю доктором реабилитационной медицины в ФК "Қайрат".
            </p>
            <p>
              Специализируюсь на спортивной реабилитации и имею опыт работы с профессиональными спортсменами в
              Казахстанской Премьер Лиге.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
            <Button asChild className="bg-blue-600 hover:bg-blue-700">
              <Link href="/career">Моя карьера</Link>
            </Button>
            <Button variant="outline" asChild className="border-blue-200 hover:bg-blue-50">
              <Link href="/research">Исследования</Link>
            </Button>
          </div>
        </div>
        <div className="mx-auto lg:mx-0 flex items-center justify-center">
          <div className="relative h-[350px] w-[350px] overflow-hidden rounded-full bg-blue-50 border-4 border-blue-100">
            <Image src="/images/profile-photo.png" alt="Бекжан Пирмаханов" fill className="object-cover" priority />
          </div>
        </div>
      </div>

      <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        <Card className="border-blue-100 shadow-sm">
          <CardContent className="p-6">
            <div className="flex flex-col gap-2">
              <h3 className="text-lg font-semibold text-blue-700">Образование</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <span className="font-medium">PhD, Общественное Здравоохранение</span>
                  <p className="text-muted-foreground">Казахский Национальный Университет им.аль-Фараби, 2020-2023</p>
                </li>
                <li>
                  <span className="font-medium">Врач Общей Практики</span>
                  <p className="text-muted-foreground">
                    Казахский Национальный Медицинский Университет им. С.Д. Асфендиярова, 2016-2018
                  </p>
                </li>
                <li>
                  <span className="font-medium">Бакалавр Общей Медицины</span>
                  <p className="text-muted-foreground">
                    Казахский Национальный Медицинский Университет им. С.Д. Асфендиярова, 2011-2016
                  </p>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-100 shadow-sm">
          <CardContent className="p-6">
            <div className="flex flex-col gap-2">
              <h3 className="text-lg font-semibold text-blue-700">Языки</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex justify-between">
                  <span>Казахский</span>
                  <span className="text-muted-foreground">Родной</span>
                </li>
                <li className="flex justify-between">
                  <span>Русский</span>
                  <span className="text-muted-foreground">Свободно</span>
                </li>
                <li className="flex justify-between">
                  <span>Английский</span>
                  <span className="text-muted-foreground">Свободно</span>
                </li>
                <li className="flex justify-between">
                  <span>Французский</span>
                  <span className="text-muted-foreground">Базовый</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card className="border-blue-100 shadow-sm">
          <CardContent className="p-6">
            <div className="flex flex-col gap-2">
              <h3 className="text-lg font-semibold text-blue-700">Контакты</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4" />
                  <span>+7 (708) 238 26 18</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>pirmakhanov.b@gmail.com</span>
                </div>
                <div className="flex items-center gap-2">
                  <WhatsappIcon className="h-4 w-4" />
                  <a
                    href="https://wa.me/77082382618?text=Сәлеметсіз%20бе!%20Мен%20консультацияға%20жазылғым%20келеді.%20Здравствуйте!%20Хочу%20записаться%20на%20консультацию"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline hover:text-blue-700"
                  >
                    WhatsApp
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Instagram className="h-4 w-4" />
                  <a
                    href="https://www.instagram.com/bekzhan.rehab.doc?igsh=MXdyYjZlOWU2NGhwaA=="
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline hover:text-blue-700"
                  >
                    @bekzhan.rehab.doc
                  </a>
                </div>
                <div className="flex items-center gap-2 pt-2">
                  <span className="text-xs text-muted-foreground">ORCID:</span>
                  <a
                    href="https://orcid.org/0000-0002-1512-8141"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs hover:underline hover:text-blue-700"
                  >
                    0000-0002-1512-8141
                  </a>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-16">
        <Card className="border-blue-100 shadow-sm">
          <CardContent className="p-6 md:p-8">
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-blue-700">Частные консультации</h2>
              <p>
                Принимаю на частные консультации в спортивном центре <strong>Back to Move</strong>.
              </p>
              <div>
                <h3 className="text-lg font-medium mb-2">С чем ко мне можно обратиться:</h3>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Спортивные и бытовые травмы</li>
                  <li>Реабилитация после операций, предоперационная подготовка</li>
                  <li>Острые и хронические боли</li>
                  <li>Профилактика травм, спортивная и кондиционная подготовка</li>
                  <li>Оптимизация тренировочного процесса спортивных команд</li>
                </ul>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <a
                    href="https://wa.me/77082382618?text=Сәлеметсіз%20бе!%20Мен%20консультацияға%20жазылғым%20келеді.%20Здравствуйте!%20Хочу%20записаться%20на%20консультацию"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    <WhatsappIcon className="h-4 w-4" />
                    Записаться на консультацию
                  </a>
                </Button>
                <Button variant="outline" asChild className="border-blue-200 hover:bg-blue-50">
                  <Link href="/certificates">Мои сертификаты</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
