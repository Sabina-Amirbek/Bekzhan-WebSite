import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Download, MapPin, Calendar } from "lucide-react"
import Image from "next/image"

export default function CertificatesPage() {
  const certificates = [
    {
      id: 1,
      title: "World anti-doping agency (WADA). ADeL Sport Physician's Tool Kit Certificate",
      location: "Онлайн",
      year: "2019",
      image: "/images/cert-wada.png",
      className: "",
    },
    {
      id: 2,
      title: "The Federation Internationale de Football Association (FIFA). FIFA Diploma in Football Medicine",
      location: "Онлайн",
      year: "2019",
      image: "/images/cert-fifa.png",
      className: "",
    },
    {
      id: 3,
      title: "MULLIGAN. Manual Therapy Concept",
      location: "Астана, Казахстан",
      year: "2024",
      image: "/images/cert-mulligan.png",
      className: "!object-contain transform -rotate-90 scale-[0.7]",
    },
    {
      id: 4,
      title: "Open Medical Institute (OMI). Salzburg Weill Cornell Seminar in Rehabilitation Medicine",
      location: "Австрия",
      year: "2024",
      image: "/images/cert-omi-1.png",
      className: "",
    },
    {
      id: 5,
      title: "Open Medical Institute (OMI). Certificate",
      location: "Австрия",
      year: "2024",
      image: "/images/cert-omi-2.png",
      className: "!object-contain transform -rotate-90 scale-[0.7]",
    },
  ]

  return (
    <div className="container px-4 py-12">
      <div className="space-y-2 text-center mb-8">
        <h1 className="text-3xl font-bold">Сертификаты</h1>
        <p className="text-muted-foreground">Повышение квалификации и профессиональное развитие</p>
        <div className="flex justify-center mt-4">
          <Button variant="outline" asChild>
            <a href="/resume.pdf" download className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Скачать полное резюме
            </a>
          </Button>
        </div>
      </div>

      <div className="grid gap-8 md:grid-cols-2 max-w-5xl mx-auto">
        {certificates.map((cert) => (
          <Card key={cert.id} className="overflow-hidden border-blue-100 shadow-sm">
            <div className="relative h-64 w-full bg-white flex items-center justify-center">
              <div className="relative w-full h-full">
                <Image
                  src={cert.image || "/placeholder.svg"}
                  alt={cert.title}
                  fill
                  className={`object-contain p-2 ${cert.className}`}
                />
              </div>
            </div>
            <CardHeader className="pb-2 bg-blue-50">
              <CardTitle className="text-lg">{cert.title}</CardTitle>
            </CardHeader>
            <CardContent className="bg-blue-50">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{cert.location}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>{cert.year}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
