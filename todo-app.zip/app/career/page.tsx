import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function CareerPage() {
  return (
    <div className="container px-4 py-12">
      <div className="space-y-2 text-center mb-8">
        <h1 className="text-3xl font-bold">Карьера</h1>
        <p className="text-muted-foreground">Мой профессиональный опыт и достижения</p>
      </div>

      <div className="space-y-8 max-w-3xl mx-auto">
        <div className="relative pl-8 border-l-2 border-muted pb-12">
          <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px] top-0"></div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-muted-foreground">2022 - по настоящее время</span>
            </div>
            <h3 className="text-xl font-semibold">Доктор Реабилитационной Медицины</h3>
            <p className="text-muted-foreground">ФК "Қайрат" - Казахстанская Премьер Лига</p>
            <div className="mt-2 text-sm">
              <p>
                Работа с профессиональными футболистами высшего дивизиона. Разработка и внедрение программ реабилитации
                после травм, профилактика травматизма, восстановление спортсменов.
              </p>
            </div>
          </div>
        </div>

        <div className="relative pl-8 border-l-2 border-muted pb-12">
          <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px] top-0"></div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-muted-foreground">2023 - по настоящее время</span>
            </div>
            <h3 className="text-xl font-semibold">Старший преподаватель</h3>
            <p className="text-muted-foreground">Казахская Академия Спорта и Туризма</p>
            <div className="mt-2 text-sm">
              <p>
                Преподавание дисциплин, связанных со спортивной медициной и реабилитацией. Проведение научных
                исследований и руководство студенческими работами.
              </p>
            </div>
          </div>
        </div>

        <div className="relative pl-8 border-l-2 border-muted pb-12">
          <div className="absolute w-4 h-4 bg-primary rounded-full -left-[9px] top-0"></div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-muted-foreground">2018 - 2021</span>
            </div>
            <h3 className="text-xl font-semibold">Глава департамента реабилитации</h3>
            <p className="text-muted-foreground">Молодежная Академия ФК "Қайрат"</p>
            <div className="mt-2 text-sm">
              <p>
                Руководство отделом реабилитации в молодежной академии. Разработка и внедрение программ реабилитации для
                молодых спортсменов, координация работы специалистов, контроль качества реабилитационных мероприятий.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-16 space-y-6 max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold">Образование</h2>

        <Card>
          <CardHeader>
            <CardTitle>Академическое образование</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <h3 className="font-medium">PhD, Общественное Здравоохранение</h3>
                <span className="text-sm text-muted-foreground">2020 - 2023</span>
              </div>
              <p className="text-sm text-muted-foreground">Казахский Национальный Университет им.аль-Фараби</p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <h3 className="font-medium">Спортивная медицина и Реабилитация</h3>
                <span className="text-sm text-muted-foreground">2018 - 2020</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Казахский Медицинский Университет Непрерывного Образования
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <h3 className="font-medium">Врач Общей Практики</h3>
                <span className="text-sm text-muted-foreground">2016 - 2018</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Казахский Национальный Медицинский Университет им. С.Д. Асфендиярова
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <h3 className="font-medium">Бакалавр Общей Медицины</h3>
                <span className="text-sm text-muted-foreground">2011 - 2016</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Казахский Национальный Медицинский Университет им. С.Д. Асфендиярова
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
